#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include "tp2.h"
#include "args.h"

typedef struct timeval Time;

int main (int argc, char *argv[]) {

	arg entrada, saida;

	struct rusage usage;
	struct timeval start,end;

	int colunas,linhas,**vertices,**resultado,*resp,i,j,somas;

	double tempo;
	Time inicio, fim;
	
	entrada = leitura_parametro(argc,argv);

	getrusage(RUSAGE_SELF,&usage);
	start = usage.ru_stime;
	gettimeofday(&inicio,0);

	FILE *arq;
	FILE *arq2;
	arq = fopen(entrada.i,"r");
	arq2 = fopen(entrada.o,"w");
	
	while(fscanf(arq,"%d",&linhas)!=EOF) {	

		//fscanf(arq,"%d",&linhas);
		fscanf(arq,"%d",&colunas);

		vertices=alocarmatriz(linhas,colunas);
		resultado=alocarmatriz(linhas,colunas);
	
		for(i = 0;i < linhas;i++){
			for(j = 0;j < colunas;j++){
				fscanf(arq,"%d",&vertices[i][j]);
			}
		}


		resp=calcprimeiracoluna(vertices,resultado,linhas);

		for(i=0;i<linhas;i++){
			resultado[i][0]=resp[i];
		}

		calculaall(vertices,resultado,linhas,colunas);

		for(i = 0;i < linhas;i++){
			for(j = 0;j < colunas;j++){
				printf("%d\t", resultado[i][j]);
				fprintf(arq2,"%d\t",resultado[i][j]);
			}
		printf("\n");
		fprintf(arq2,"\n");
		}

		getrusage(RUSAGE_SELF, &usage);
		end = usage.ru_stime;
		gettimeofday(&fim, 0);
		tempo = (fim.tv_sec + fim.tv_usec/1000000.0) - (inicio.tv_sec  + inicio.tv_usec/1000000.0);
		printf("Tempo do sistema: %f segundos\n",tempo);
		printf("Tempo de usuário: Começo: %ld.%lds\n",start.tv_sec,start.tv_usec);
		printf("Tempo de usuário: Fim: %ld.%lds\n",end.tv_sec,end.tv_usec);
	}
		
	fclose(arq);
	fclose(arq2);
	return 0;

}
