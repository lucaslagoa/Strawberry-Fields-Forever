#ifndef TP2_H
#define	TP2_H
#include <stdio.h>
#include <stdlib.h>

// título das funções que foram utilizadas na main

void calculaall (int **vertices, int **resultado, int linhas, int colunas);
int *calcprimeiracoluna(int **vertices, int **resultado,int linhas);
int **alocarmatriz (int linhas, int colunas);
int resposta (int **resultado, int linhas, int colunas);

#endif
