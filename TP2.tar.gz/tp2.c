#include "tp2.h"

int **alocarmatriz (int linhas, int colunas) { 
	int **vetormorango,i;
	vetormorango = malloc ( linhas *sizeof (int));
	for(i = 0;i < linhas; i++) {
		vetormorango[i]= (int *) malloc (colunas *sizeof(int));
	}
	return vetormorango;
}

int *calcprimeiracoluna(int **vertices, int **resultado,int linhas) {

	int i,j,soma=0,*vetorUp,*vetorDown,*resp;

	vetorUp = malloc ( linhas *sizeof (int));
	vetorDown = malloc ( linhas *sizeof (int));
	resp = malloc ( linhas *sizeof (int));

		for (i = 0; i < linhas; i++){
			
			for (j = i; (j >= 0) && (vertices[j][0] != 0 ); j--) { //sobe
					soma=soma+vertices[j][0];
			}

			vetorUp[i]=soma;
			soma=0;

			for (j = i; (j < linhas) && (vertices[j][0] != 0) ; j++) { //desce
					soma=soma+vertices[j][0];
				}

			vetorDown[i]=soma;
			soma=0;

			if (vetorUp[i] > vetorDown[i]) {
				resp[i]=resp[i]+vetorUp[i];
			} else { 
				resp[i]=resp[i]+vetorDown[i];
			}
			}
		
	return resp;	
}

void calculaall (int **vertices, int **resultado, int linhas, int colunas) {

	int i,j,*vetorSubida,*vetorDescida,*newVetorSubida,*newVetorDescida,*newVetorOtimo;

	vetorSubida = malloc ( linhas *sizeof (int));
	vetorDescida = malloc ( linhas *sizeof (int));
	newVetorSubida = malloc ( linhas *sizeof (int));
	newVetorDescida = malloc ( linhas *sizeof (int));
	newVetorOtimo = malloc ( linhas *sizeof (int));

	for(j=1;j<colunas;j++) {
		for(i=0; i<linhas ; i++){ //vetores de subida e descida recebem 
			if ( vertices[i][j] == 0 || resultado[i][j-1] == 0) {
				vetorSubida[i] = 0;
				vetorDescida[i] = 0;
			} else {
				vetorSubida[i]=	resultado[i][j-1] + vertices[i][j];
				vetorDescida[i]= resultado[i][j-1] + vertices[i][j];
			}
		}

	
	if (vetorSubida[linhas-1] > vertices[linhas-1][j]) { //comparação da borda de subida
		newVetorSubida[linhas-1] = vetorSubida[linhas-1];
	} else {
		newVetorSubida[linhas-1] = vertices[linhas-1][j]; 
	}


	for (i=linhas-2; i>=0 ;i--) { //subida
		if ((vetorSubida[i] == 0)  && (vertices[i][j] == 0)) {
			newVetorSubida[i]=0;
		} else if(vertices[i+1][j] != 0 && newVetorSubida[i+1] != 0 && (newVetorSubida[i+1]+vertices[i][j] > vetorSubida[i])) {
			newVetorSubida[i] = newVetorSubida[i+1] + vertices[i][j];
		} else {
			newVetorSubida[i] = vetorSubida[i];
		}
	}

	if	(vetorDescida[0] < vertices[0][j]) { //borda de descida
		newVetorDescida[0] = vertices[0][j];
	} else {
		newVetorDescida[0] = vetorDescida[0];
	}


	for (i=1;i<linhas;i++) { //descida
		if((vetorDescida[i] == 0) && (vertices[i][j] == 0)){
			newVetorDescida[i] = 0;
		} else if (vertices[i-1][j] != 0 && newVetorDescida[i-1] != 0 && (newVetorDescida[i-1]+vertices[i][j] > vetorDescida[i])) {
				newVetorDescida[i] = newVetorDescida[i-1] + vertices[i][j];
				
		} else {
				newVetorDescida[i] = vetorDescida[i];

		}
	}
	

	for(i=0;i<linhas;i++) { //maiores valores para utilizar no vetor Ótimo
		if(newVetorSubida[i] >= newVetorDescida[i]){
			newVetorOtimo[i] = newVetorSubida[i];
		} else {
			newVetorOtimo[i] = newVetorDescida[i];
		}
	}

	for(i=0;i<linhas;i++){
		resultado[i][j]=newVetorOtimo[i];
	}		
	}
}

int resposta (int **resultado, int linhas, int colunas) {

	//vetormaior = malloc ( linhas *sizeof (int));
	int i,maior=0;


	for(i=0;i<linhas;i++) {
		if(maior < resultado[i][colunas-1]){
			maior = resultado[i][colunas-1];
		}
	}
	//printf("%d\n", maior);
	return maior;
}

/*void verificacaminho (int *newVetorOtimo, int linhas, int colunas) {

	int i,j,verifica;

	for(j = 1; j < colunas; j++) {
		for (i = 0; i < linhas; i++) {
			if (newVetorOtimo[i] != 0){
				verifica=0;
			} else {
				verifica=1;
			}
		}
	}
}*/


